﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Banking_App
{
    public partial class Form2 : Form
    {
        public static Form2 instance;
   
        public Form2()
        {
            InitializeComponent();
            instance = this;
            accountType();
        }
       
      public static String AccNm, full_Name,item;
      public static double balance;
     //  List<String> list = new List<string>();     
        private void btnCreate_Click(object sender, EventArgs e)
        {
            String fName = fNamebox1.Text;
            String lName = lstNameBox1.Text;
            double bal = Convert.ToDouble(balanceBox1.Text);  
            item = this.accTypeBox1.SelectedItem.ToString();

            if (item.Equals("Checking"))
            {
                CheckingAccount chk = new CheckingAccount(fName, lName, bal, 0.00);
                chk.SetBalance(bal);
                chk.DoDeposit(Form3.deposit);
                chk.SetMcharges(2.59);

                randomChkAccountNumber();
                full_Name = chk.getName();
                balance = chk.GetBalance();

                //      list.Add(AccNm); list.Add(full_Name); list.Add(balance); list.Add(item);

                //label6.Text = chk.ToString();
               
                MessageBox.Show("Checking Account Created Successfully");
                this.Close();

            }
            else if (item.Equals("Savings"))
            {
                SavingsAccount svg = new SavingsAccount(fName, lName, bal, 0.00);
                svg.SetMiniBalance(200.00);
                svg.SetBalance(bal);
                svg.DoDeposit(Form3.deposit);
                randomSvgAccountNumber();

                full_Name = svg.getName();
                balance = svg.GetBalance();

                //   list.Add(AccNm); list.Add(full_Name); list.Add(balance); list.Add(item);
               
                MessageBox.Show("Savings Account Created Successfully");
                this.Close();
            }
            else if(item.Equals(null))
            {
                MessageBox.Show("Please Select A Valid Account Type!");
            }
            
        }


        private void randomChkAccountNumber() {
            Random r = new Random();
            int rInt = r.Next(5999, 9999); //for ints
            AccNm = "A00C" + rInt.ToString();
            accNumBox1.Text = AccNm;
        }

        private void randomSvgAccountNumber()
        {
            Random r = new Random();
            int rInt = r.Next(1199, 9999); //for ints
            AccNm = "A00S" + rInt.ToString();
            accNumBox1.Text = AccNm;
        }
        private void accountType() {
            string[] accTypes = { "Checking", "Savings"};
            for (int i = 0; i < accTypes.Length;i++) {
                accTypeBox1.Items.Add(accTypes[i]);
            }
        }
    }
}
