﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking_App
{
    public class CheckingAccount : Account
    {
        private const int TansactionNumber = 50;
        private double monthlyCharges;
        public CheckingAccount()
        {
            monthlyCharges = 0.0;
        }
        public CheckingAccount(String fName, String lName, double bal, double mCharges) : base(fName, lName, bal)
        {
            this.monthlyCharges = mCharges;
        }
        public double GetMcharges()
        {
            return this.monthlyCharges;
        }
        public void SetMcharges(double charge)
        {
            this.monthlyCharges = charge;
        }

        public override String ToString()
        {
            String nStr = monthlyCharges.ToString();
            String nStr2 = TansactionNumber.ToString();
            base.ToString();
            Console.WriteLine("Account Type: Checking Account");
            Console.WriteLine("Monthly Charges: $ {0}", nStr);
            Console.WriteLine("Maximum Number of Free Transactions: {0}", nStr2);
            return nStr;
        }
    }
}
