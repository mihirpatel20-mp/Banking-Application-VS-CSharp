﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking_App
{
    public class Account
    {
        public String first_name, last_name, info, fullname;
        public double balance;
        public Account()
        {
            first_name = "";
            last_name = "";
            balance = 0;
        }

        public Account(String fName, String lName, double bal)
        {
            this.first_name = fName;
            this.last_name = lName;
            this.balance = bal;
        }

        public String getName()
        {
            fullname = this.first_name + this.last_name;
            return fullname;
        }

        public void setName()
        {
            this.fullname = this.first_name + this.last_name;
        }

        public double GetBalance()
        {
            return this.balance;
        }

        public void SetBalance(double bal)
        {
            this.balance = bal;
        }

        public void DoDeposit(double deposit)
        {
            this.balance += deposit;
        }

        public void DoWithdrawal(double withdraw)
        {
            this.balance -= withdraw;
        }

        public override String ToString()
        {
            String full_Name = first_name + " " + last_name;
            String bal = "$ " + balance.ToString();
            String infoAccount = full_Name + " " + bal;
            this.info = infoAccount;
            Console.WriteLine(infoAccount);
            return infoAccount;
        }
    }
}
