﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking_App
{
    public class SavingsAccount : Account
    {
        private double minimumBalance;

        public SavingsAccount()
        {
            minimumBalance = 0.0;
        }
        public SavingsAccount(String fName, String lName, double bal, double miniBal) : base(fName, lName, bal)
        {
            this.minimumBalance = miniBal;
        }
        public double GetMinibalance()
        {
            return this.minimumBalance;
        }
        public void SetMiniBalance(double mBal)
        {
            this.minimumBalance = mBal;
        }

        public override String ToString()
        {
            String nStr = minimumBalance.ToString();
            base.ToString();
            Console.WriteLine("Account Type: Savings Account");
            Console.WriteLine("Minimum Balance Required is : $ {0}", nStr);
            return nStr;
        }
    }
}
