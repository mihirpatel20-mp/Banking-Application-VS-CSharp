﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Banking_App
{
    public partial class Form1 : Form
    {
        public static Form1 instance;
        public static ListView lst;
        public static double mBalance;

        public Form1()
        {
            InitializeComponent();
            instance = this;
            lst = listView1;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            fNamebox.ReadOnly = true;
            balanceBox.ReadOnly = true;
            accTypeBox.ReadOnly = true;
            accNumBox.ReadOnly = true;
        }

        private void openBtn_Click(object sender, EventArgs e)
        {
            var myForm = new Form2();
            myForm.Show();
        }

        private void listAllBtn_Click(object sender, EventArgs e)
        {
            string str1 = Form2.balance.ToString();
            String[] row = { Form2.AccNm, Form2.full_Name, str1, Form2.item };
            ListViewItem list = new ListViewItem(row);
      
            lst.Items.Add(list);
            lst.FullRowSelect = true;
        }

        private void depositBtn_Click(object sender, EventArgs e)
        {
            var myForm = new Form3();
            myForm.Show();
        }

        private void withdrawBtn_Click(object sender, EventArgs e)
        {
            var myForm1 = new Form3();
            myForm1.Show();
        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            fNamebox.Text = lst.SelectedItems[0].SubItems[1].Text;
            accTypeBox.Text = lst.SelectedItems[0].SubItems[3].Text;
            balanceBox.Clear();
            accNumBox.Clear();
        }

        private void btn_ClickMe_Click(object sender, EventArgs e)
        {
            mBalance = Convert.ToDouble(lst.SelectedItems[0].SubItems[2].Text.ToString());

            balanceBox.Text = "$ " + lst.SelectedItems[0].SubItems[2].Text;
        }

        private void btnClickToSee_Click(object sender, EventArgs e)
        {
            accNumBox.Text = lst.SelectedItems[0].SubItems[0].Text;
        }

        private void exiBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}