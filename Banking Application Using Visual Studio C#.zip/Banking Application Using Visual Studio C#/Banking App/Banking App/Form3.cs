﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Banking_App
{
    public partial class Form3 : Form
    {
        public static Form3 instance;
        public static string num;
        public static double deposit;
        public Form3()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            num = depositBox.Text.ToString();
            deposit = Convert.ToDouble(num);

            double total = Form1.mBalance + deposit;
         
      
            MessageBox.Show("$ "+ deposit + " Deposited to your Account\n  Total Amount is: $" + total);
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            num = depositBox.Text.ToString();
            deposit = Convert.ToDouble(num);

            double total = Form1.mBalance - deposit;
         
      
            MessageBox.Show("$ "+ deposit + " Withdrawn from your Account\n  Total Amount is: $" + total);
            this.Close();

        }
    }
}
