﻿namespace Banking_App
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fNamebox = new System.Windows.Forms.TextBox();
            this.balanceBox = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.accTypeBox = new System.Windows.Forms.TextBox();
            this.btnClickToSee = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.accNumBox = new System.Windows.Forms.TextBox();
            this.btn_ClickMe = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.openBtn = new System.Windows.Forms.Button();
            this.listAccBtn = new System.Windows.Forms.Button();
            this.depositBtn = new System.Windows.Forms.Button();
            this.withdrawBtn = new System.Windows.Forms.Button();
            this.listAllBtn = new System.Windows.Forms.Button();
            this.exiBtn = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // fNamebox
            // 
            this.fNamebox.Location = new System.Drawing.Point(107, 59);
            this.fNamebox.Name = "fNamebox";
            this.fNamebox.Size = new System.Drawing.Size(236, 20);
            this.fNamebox.TabIndex = 0;
            // 
            // balanceBox
            // 
            this.balanceBox.Location = new System.Drawing.Point(107, 100);
            this.balanceBox.Name = "balanceBox";
            this.balanceBox.Size = new System.Drawing.Size(236, 20);
            this.balanceBox.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.groupBox1.Controls.Add(this.accTypeBox);
            this.groupBox1.Controls.Add(this.btnClickToSee);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.accNumBox);
            this.groupBox1.Controls.Add(this.btn_ClickMe);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.fNamebox);
            this.groupBox1.Controls.Add(this.balanceBox);
            this.groupBox1.Location = new System.Drawing.Point(112, 89);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(454, 366);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Account Holder";
            // 
            // accTypeBox
            // 
            this.accTypeBox.Location = new System.Drawing.Point(107, 142);
            this.accTypeBox.Name = "accTypeBox";
            this.accTypeBox.Size = new System.Drawing.Size(119, 20);
            this.accTypeBox.TabIndex = 12;
            // 
            // btnClickToSee
            // 
            this.btnClickToSee.Location = new System.Drawing.Point(188, 321);
            this.btnClickToSee.Name = "btnClickToSee";
            this.btnClickToSee.Size = new System.Drawing.Size(116, 28);
            this.btnClickToSee.TabIndex = 11;
            this.btnClickToSee.Text = "Click To See";
            this.btnClickToSee.UseVisualStyleBackColor = true;
            this.btnClickToSee.Click += new System.EventHandler(this.btnClickToSee_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 244);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Account Number";
            // 
            // accNumBox
            // 
            this.accNumBox.Location = new System.Drawing.Point(107, 237);
            this.accNumBox.Name = "accNumBox";
            this.accNumBox.Size = new System.Drawing.Size(236, 20);
            this.accNumBox.TabIndex = 9;
            // 
            // btn_ClickMe
            // 
            this.btn_ClickMe.Location = new System.Drawing.Point(201, 188);
            this.btn_ClickMe.Name = "btn_ClickMe";
            this.btn_ClickMe.Size = new System.Drawing.Size(75, 23);
            this.btn_ClickMe.TabIndex = 8;
            this.btn_ClickMe.Text = "Click Me!";
            this.btn_ClickMe.UseVisualStyleBackColor = true;
            this.btn_ClickMe.Click += new System.EventHandler(this.btn_ClickMe_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Account Type";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Account Balance";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Account Holder";
            // 
            // openBtn
            // 
            this.openBtn.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.openBtn.Location = new System.Drawing.Point(112, 501);
            this.openBtn.Name = "openBtn";
            this.openBtn.Size = new System.Drawing.Size(110, 26);
            this.openBtn.TabIndex = 5;
            this.openBtn.Text = "Open an Account";
            this.openBtn.UseVisualStyleBackColor = false;
            this.openBtn.Click += new System.EventHandler(this.openBtn_Click);
            // 
            // listAccBtn
            // 
            this.listAccBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.listAccBtn.Location = new System.Drawing.Point(278, 501);
            this.listAccBtn.Name = "listAccBtn";
            this.listAccBtn.Size = new System.Drawing.Size(110, 26);
            this.listAccBtn.TabIndex = 6;
            this.listAccBtn.Text = "List an Account";
            this.listAccBtn.UseVisualStyleBackColor = false;
            // 
            // depositBtn
            // 
            this.depositBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.depositBtn.Location = new System.Drawing.Point(456, 501);
            this.depositBtn.Name = "depositBtn";
            this.depositBtn.Size = new System.Drawing.Size(110, 26);
            this.depositBtn.TabIndex = 7;
            this.depositBtn.Text = "Deposit Money";
            this.depositBtn.UseVisualStyleBackColor = false;
            this.depositBtn.Click += new System.EventHandler(this.depositBtn_Click);
            // 
            // withdrawBtn
            // 
            this.withdrawBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.withdrawBtn.Location = new System.Drawing.Point(745, 501);
            this.withdrawBtn.Name = "withdrawBtn";
            this.withdrawBtn.Size = new System.Drawing.Size(110, 26);
            this.withdrawBtn.TabIndex = 8;
            this.withdrawBtn.Text = "Withdraw Money";
            this.withdrawBtn.UseVisualStyleBackColor = false;
            this.withdrawBtn.Click += new System.EventHandler(this.withdrawBtn_Click);
            // 
            // listAllBtn
            // 
            this.listAllBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.listAllBtn.Location = new System.Drawing.Point(915, 501);
            this.listAllBtn.Name = "listAllBtn";
            this.listAllBtn.Size = new System.Drawing.Size(110, 26);
            this.listAllBtn.TabIndex = 9;
            this.listAllBtn.Text = "List all Accounts";
            this.listAllBtn.UseVisualStyleBackColor = false;
            this.listAllBtn.Click += new System.EventHandler(this.listAllBtn_Click);
            // 
            // exiBtn
            // 
            this.exiBtn.BackColor = System.Drawing.Color.Red;
            this.exiBtn.Location = new System.Drawing.Point(1074, 501);
            this.exiBtn.Name = "exiBtn";
            this.exiBtn.Size = new System.Drawing.Size(102, 26);
            this.exiBtn.TabIndex = 10;
            this.exiBtn.Text = "Exit Application";
            this.exiBtn.UseVisualStyleBackColor = false;
            this.exiBtn.Click += new System.EventHandler(this.exiBtn_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.IndianRed;
            this.groupBox2.Controls.Add(this.listView1);
            this.groupBox2.Location = new System.Drawing.Point(745, 89);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(431, 366);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Account Details";
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(6, 26);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(419, 334);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseDoubleClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Account_ID";
            this.columnHeader1.Width = 100;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Account_Holder";
            this.columnHeader2.Width = 100;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Account_Balance";
            this.columnHeader3.Width = 100;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Account_Type";
            this.columnHeader4.Width = 100;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(534, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(271, 31);
            this.label6.TabIndex = 13;
            this.label6.Text = "Banking Application";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(281, 68);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 18);
            this.label7.TabIndex = 14;
            this.label7.Text = "Input Area";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(1220, 561);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.exiBtn);
            this.Controls.Add(this.listAllBtn);
            this.Controls.Add(this.withdrawBtn);
            this.Controls.Add(this.depositBtn);
            this.Controls.Add(this.listAccBtn);
            this.Controls.Add(this.openBtn);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox fNamebox;
        private System.Windows.Forms.TextBox balanceBox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnClickToSee;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_ClickMe;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button openBtn;
        private System.Windows.Forms.Button listAccBtn;
        private System.Windows.Forms.Button depositBtn;
        private System.Windows.Forms.Button withdrawBtn;
        private System.Windows.Forms.Button listAllBtn;
        private System.Windows.Forms.Button exiBtn;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox accNumBox;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.TextBox accTypeBox;
    }
}

